"""Imports Crypto Protocol

Now you can do:
    >>> from CryptoPlus.Protocol import *
OR:
    >>> from CryptoPlus.Protocol import XXX
but not:
    >>> import CryptoPlus.Protocol.XXX
"""
from Crypto.Protocol import *
