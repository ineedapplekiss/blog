from Crypto.Random import *
from Crypto.Random import _UserFriendlyRNG, atfork, random
