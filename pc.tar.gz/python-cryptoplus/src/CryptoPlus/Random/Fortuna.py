from Crypto.Random.Fortuna import *
